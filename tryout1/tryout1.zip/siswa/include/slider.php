
<div class="row content">
	<div class="slider">
		<ul>
		     <li>
				<a href="#">
					<img alt="Images 1" src="img/ars-1.jpg" />
				</a>

				<!--<div>
				    <h3>Title #1</h3>
				    <p>Content Text...</p>
				</div>-->
		     </li>

		     <li>
		        <a href="#">
		        	<img alt="Images 2" src="img/siswa-lulus.jpg" />
		        </a>

				<!--<div>
				    <h3>Title #1</h3>
				    <p>Content Text...</p>
				</div>-->
		     </li>
		     <li>
				<a href="#">
					<img alt="Images 1" src="img/buku-adzkia.png" />
				</a>

				<!--<div>
				    <h3>Title #1</h3>
				    <p>Content Text...</p>
				</div>-->
		     </li>

		     <li>
		        <a href="#">
		        	<img alt="Images 2" src="img/siswa-lulus.jpg" />
		        </a>

				<!--<div>
				    <h3>Title #1</h3>
				    <p>Content Text...</p>
				</div>-->
		     </li>
		</ul> 
	</div>
</div>