<div class="row">
	<div class="col-md-12">
		<ul class="nav nav-pills menunav">
		  <li><a href="index.php">Home</a></li>
					<li><a href="index.php?p=profil.php">Profil</a></li>
					<li><a href="index.php?p=jadwal.php">Tryout</a></li>
					<li><a href="index.php?p=video/index.php"> Video Materi</a></li>
					<li><a href="index.php?p=ebook/index.php"> Ebook</a></li>
					<li><a href="index.php?p=logout.php">Logout</a></li>
		</ul>
		<form class="navbar-form navbar-right formhead" role="search">
				<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
				</div>
				<button type="submit" class="btn btn-default">Search</button>
		</form>
	</div>
</div>