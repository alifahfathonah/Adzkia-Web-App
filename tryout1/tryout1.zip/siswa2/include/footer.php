<div class="pull-right hidden-xs">
  <b>Version</b> 2.3.0
</div>
<strong>Copyright 2015</strong> All rights reserved.